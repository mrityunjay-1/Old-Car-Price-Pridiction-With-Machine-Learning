from tkinter import *
from tkinter import messagebox

def HelpBar(frame1, frame2, frame3):
    frame1.pack_forget()
    frame2.pack_forget()
    frame3.pack()


def HomeMenu(frame1, frame2, frame3):
    frame1.pack()
    frame2.pack()
    frame3.pack_forget()
